setwd("C:\\Users\\it24101829\\Desktop\\IT24101829")
#1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
head(branch_data)

#2
str(branch_data)

#3
boxplot(branch_data$Sales,main="Boxplot of Sales",ylab="Sales",col="lightblue")

#4
fivenum(branch_data$Advertising)
summary(branch_data$Advertising)
IQR(branch_data$Advertising)

#5
find_outliers <- function(x){
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR<- Q3-Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound |x > upper_bound]
  return(outliers)
}
find_outliers(branch_data$Years)